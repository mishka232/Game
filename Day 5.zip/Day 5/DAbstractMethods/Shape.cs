﻿namespace DAbstractMethods
{
    abstract class Shape
    {
        public abstract double CalcSurface();
    }
}
